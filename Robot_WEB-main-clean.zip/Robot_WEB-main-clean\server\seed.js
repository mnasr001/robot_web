const dns = require("dns")
dns.setServers(["8.8.8.8", "1.1.1.1"])

const mongoose = require("mongoose")
require("dotenv").config()

const Tour = require("./models/Tour")
const Exhibit = require("./models/Exhibit")
const Question = require("./models/Question")
const Guidance = require("./models/Guidance")

const tours = require("./data/tours.json")
const exhibits = require("./data/exhibits.json")

function normalizeExhibits(exhibits) {
  return exhibits.map((exhibit) => ({
    ...exhibit,
    description:
      exhibit.description ||
      `${exhibit.name} is part of the ${exhibit.hall}. It helps visitors understand ${exhibit.purpose.toLowerCase()} and its connection to ${exhibit.period}. ${exhibit.summary}`,
  }))
}

function buildQuestions(exhibits) {
  return exhibits.flatMap((exhibit) => [
    {
      tourId: exhibit.tourId,
      exhibitId: exhibit.id,
      questionNumber: 1,
      question: `What is ${exhibit.name} used for?`,
      answer: exhibit.purpose || "No purpose is saved for this exhibit yet.",
    },
    {
      tourId: exhibit.tourId,
      exhibitId: exhibit.id,
      questionNumber: 2,
      question: `Which period does ${exhibit.name} belong to?`,
      answer: exhibit.period || "No period is saved for this exhibit yet.",
    },
    {
      tourId: exhibit.tourId,
      exhibitId: exhibit.id,
      questionNumber: 3,
      question: `Why is ${exhibit.name} important?`,
      answer: exhibit.summary || "No summary is saved for this exhibit yet.",
    },
  ])
}

function buildGuidance(exhibits) {
  return exhibits.flatMap((exhibit) => [
    {
      tourId: exhibit.tourId,
      fromExhibitId: exhibit.id,
      placeId: "toilet",
      placeName: "Toilet",
      guidance: `From ${exhibit.name}, go back to the main corridor, continue straight, then turn left at the nearest sign. The toilet area is close to the visitor services section.`,
      estimatedTime: "2-3 minutes",
      order: 1,
    },
    {
      tourId: exhibit.tourId,
      fromExhibitId: exhibit.id,
      placeId: "exit",
      placeName: "Exit",
      guidance: `From ${exhibit.name}, follow the main visitor path toward the central hall, then continue following the Exit signs until you reach the main exit gate.`,
      estimatedTime: "4-6 minutes",
      order: 2,
    },
    {
      tourId: exhibit.tourId,
      fromExhibitId: exhibit.id,
      placeId: "information-desk",
      placeName: "Information Desk",
      guidance: `From ${exhibit.name}, return to the central hall. The information desk is located near the main visitor entrance and help area.`,
      estimatedTime: "3-5 minutes",
      order: 3,
    },
    {
      tourId: exhibit.tourId,
      fromExhibitId: exhibit.id,
      placeId: "gift-shop",
      placeName: "Gift Shop",
      guidance: `From ${exhibit.name}, follow the main corridor toward the visitor services area. The gift shop is near the exit route.`,
      estimatedTime: "5-7 minutes",
      order: 4,
    },
    {
      tourId: exhibit.tourId,
      fromExhibitId: exhibit.id,
      placeId: "cafe",
      placeName: "Cafe",
      guidance: `From ${exhibit.name}, go toward the central visitor area, then follow the cafe signs. The cafe is near the rest area.`,
      estimatedTime: "4-6 minutes",
      order: 5,
    },
  ])
}

async function seedDatabase() {
  try {
    if (!process.env.MONGODB_URI) {
      throw new Error("MONGODB_URI is missing. Add it inside server/.env")
    }

    await mongoose.connect(process.env.MONGODB_URI, {
      serverSelectionTimeoutMS: 10000,
    })

    const exhibitsWithDescriptions = normalizeExhibits(exhibits)
    const questions = buildQuestions(exhibitsWithDescriptions)
    const guidanceItems = buildGuidance(exhibitsWithDescriptions)

    await Tour.deleteMany({})
    await Exhibit.deleteMany({})
    await Question.deleteMany({})
    await Guidance.deleteMany({})

    await Tour.insertMany(tours)
    await Exhibit.insertMany(exhibitsWithDescriptions)
    await Question.insertMany(questions)
    await Guidance.insertMany(guidanceItems)

    console.log(`✅ Inserted ${tours.length} tours`)
    console.log(`✅ Inserted ${exhibitsWithDescriptions.length} exhibits`)
    console.log(`✅ Inserted ${questions.length} questions`)
    console.log(`✅ Inserted ${guidanceItems.length} guidance items`)
    console.log("✅ Database seeding finished")
  } catch (error) {
    console.error("❌ Seeding failed")
    console.error(error.message)
  } finally {
    await mongoose.disconnect()
  }
}

seedDatabase()