const express = require("express")
const Exhibit = require("../models/Exhibit")

const router = express.Router()

router.get("/", async (req, res) => {
  try {
    const filter = req.query.tourId ? { tourId: req.query.tourId } : {}
    const exhibits = await Exhibit.find(filter).sort({ id: 1 })
    res.json(exhibits)
  } catch (error) {
    res.status(500).json({ message: error.message })
  }
})

router.get("/:tourId/:exhibitId", async (req, res) => {
  try {
    const exhibit = await Exhibit.findOne({
      tourId: req.params.tourId,
      id: Number(req.params.exhibitId),
    })

    if (!exhibit) return res.status(404).json({ message: "Exhibit not found" })
    res.json(exhibit)
  } catch (error) {
    res.status(500).json({ message: error.message })
  }
})

router.get("/:tourId/:exhibitId/next", async (req, res) => {
  try {
    const nextExhibit = await Exhibit.findOne({
      tourId: req.params.tourId,
      id: { $gt: Number(req.params.exhibitId) },
    }).sort({ id: 1 })

    res.json(nextExhibit || null)
  } catch (error) {
    res.status(500).json({ message: error.message })
  }
})

module.exports = router
