import { useEffect, useState } from "react"
import { useNavigate, useParams } from "react-router-dom"
import { api } from "../api"
import SetupRequired from "../components/SetupRequired"

export default function ExhibitPage() {
  const navigate = useNavigate()
  const { exhibitId } = useParams()

  const tourId = localStorage.getItem("gem_tour")
  const language = localStorage.getItem("gem_language")

  const [tour, setTour] = useState(null)
  const [exhibit, setExhibit] = useState(null)
  const [nextExhibit, setNextExhibit] = useState(null)
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    if (!tourId || !language) return

    async function loadData() {
      try {
        const [tourData, exhibitData, nextData, exhibitsData] =
          await Promise.all([
            api.getTour(tourId),
            api.getExhibit(tourId, exhibitId),
            api.getNextExhibit(tourId, exhibitId),
            api.getTourExhibits(tourId),
          ])

        setTour(tourData)
        setExhibit(exhibitData)
        setNextExhibit(nextData)
        setTotal(exhibitsData.length)
      } catch (err) {
        setError(err.message)
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [tourId, language, exhibitId])

  if (!tourId || !language) {
    return <SetupRequired missingTour={!tourId} missingLanguage={!language} />
  }

  if (loading) {
    return (
      <div className="shell">
        <div className="card">
          <h1 className="card-title">Loading exhibit...</h1>
        </div>
      </div>
    )
  }

  if (error || !tour || !exhibit) {
    return (
      <div className="shell">
        <div className="card">
          <h1 className="card-title">Backend error</h1>
          <p className="card-sub">{error}</p>
        </div>
      </div>
    )
  }

  function continueTour() {
    navigate(nextExhibit ? `/exhibit/${nextExhibit.id}` : "/complete")
  }

  return (
    <div className="shell">
      <div className="card">
        <div className="step-badge">
          {tour.title} · Exhibit {exhibit.id} of {total}
        </div>

        <h1 className="card-title">Current Exhibit</h1>

        <p className="card-sub">
          Read the quick information, then choose what you want to do next.
        </p>

        <div className="exhibit-card center-card">
          <div className="artifact-icon">𓂀</div>
          <div className="exhibit-num">{exhibit.hall}</div>
          <div className="exhibit-name">{exhibit.name}</div>
          <div className="exhibit-fact">{exhibit.summary}</div>

          {exhibit.description && (
            <p className="card-sub">{exhibit.description}</p>
          )}
        </div>

        <div className="info-grid">
          <Info label="Period" value={exhibit.period} />
          <Info label="Material" value={exhibit.material} />
          <Info label="Purpose" value={exhibit.purpose} />
        </div>

        <div className="timer-bar-wrap">
          <div className="timer-bar full-bar" />
        </div>

        <button
          className="btn-ready"
          onClick={() => navigate(`/qa/${exhibit.id}`)}
        >
          Ask a Question
        </button>

        <button className="btn-primary" onClick={continueTour}>
          {nextExhibit ? "Go to Next Exhibit →" : "Complete Tour →"}
        </button>

        <button
          className="btn-ghost"
          onClick={() => navigate(`/facilities/${exhibit.id}`)}
        >
          Visitor Assistance
        </button>
      </div>
    </div>
  )
}

function Info({ label, value }) {
  return (
    <div className="info-box">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  )
}