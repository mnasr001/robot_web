const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000/api"

async function request(path, options = {}) {
  const response = await fetch(`${API_URL}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  })

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}))
    throw new Error(errorData.message || "API request failed")
  }

  return response.json()
}

export const api = {
  getTours: () => request("/tours"),

  getTour: (tourId) => request(`/tours/${tourId}`),

  getTourExhibits: (tourId) => request(`/exhibits?tourId=${tourId}`),

  getExhibit: (tourId, exhibitId) =>
    request(`/exhibits/${tourId}/${exhibitId}`),

  getNextExhibit: (tourId, exhibitId) =>
    request(`/exhibits/${tourId}/${exhibitId}/next`),

  getQuestions: (tourId, exhibitId) =>
    request(`/questions?tourId=${tourId}&exhibitId=${exhibitId}`),

  getGuidance: (tourId, exhibitId) =>
    request(`/guidance?tourId=${tourId}&fromExhibitId=${exhibitId}`),

  getVisitorByEmail: (email) =>
    request(`/visitors/${encodeURIComponent(email)}`),

  createVisitor: (visitor) =>
    request("/visitors", {
      method: "POST",
      body: JSON.stringify(visitor),
    }),

  createFeedback: (feedback) =>
    request("/feedback", {
      method: "POST",
      body: JSON.stringify(feedback),
    }),
}