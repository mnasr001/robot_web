const mongoose = require("mongoose")

const exhibitSchema = new mongoose.Schema(
  {
    tourId: { type: String, required: true, index: true },
    id: { type: Number, required: true },
    exhibitNumber: { type: Number, required: true },
    name: { type: String, required: true },
    hall: { type: String, required: true },
    subtitle: { type: String, required: true },
    period: { type: String, required: true },
    material: { type: String, required: true },
    purpose: { type: String, required: true },
    summary: { type: String, required: true },
  },
  { timestamps: true }
)

exhibitSchema.index({ tourId: 1, id: 1 }, { unique: true })

module.exports = mongoose.model("Exhibit", exhibitSchema)
