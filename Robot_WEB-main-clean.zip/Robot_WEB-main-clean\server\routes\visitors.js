const express = require("express")
const Visitor = require("../models/Visitor")

const router = express.Router()

function cleanVisitorBody(body) {
  const {
    _id,
    __v,
    createdAt,
    updatedAt,
    ...cleanData
  } = body

  return cleanData
}

router.post("/", async (req, res) => {
  try {
    const email = String(req.body.email || "").trim().toLowerCase()

    if (!email) {
      return res.status(400).json({ message: "Email is required" })
    }

    const visitorData = {
      ...cleanVisitorBody(req.body),
      email,
    }

    const visitor = await Visitor.findOneAndUpdate(
      { email },
      { $set: visitorData },
      {
        new: true,
        upsert: true,
        runValidators: true,
        setDefaultsOnInsert: true,
      }
    )

    res.status(201).json(visitor)
  } catch (error) {
    res.status(400).json({ message: error.message })
  }
})

router.get("/:email", async (req, res) => {
  try {
    const email = String(req.params.email || "").trim().toLowerCase()

    const visitor = await Visitor.findOne({ email })

    if (!visitor) {
      return res.status(404).json({ message: "Visitor not found" })
    }

    res.json(visitor)
  } catch (error) {
    res.status(500).json({ message: "Failed to load visitor" })
  }
})

module.exports = router