import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"
import { api } from "../api"

export default function TourSelectPage() {
  const navigate = useNavigate()
  const [tours, setTours] = useState([])
  const [selected, setSelected] = useState(localStorage.getItem("gem_tour") || "")
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    async function loadTours() {
      try {
        const data = await api.getTours()
        setTours(data)
      } catch (err) {
        setError(err.message)
      } finally {
        setLoading(false)
      }
    }

    loadTours()
  }, [])

  function continueToLanguage() {
    const tour = tours.find((item) => item.id === selected)
    if (!tour) return

    const hasLanguage = localStorage.getItem("gem_language")
    const hasHeadphone = localStorage.getItem("gem_headphone")

    localStorage.setItem("gem_tour", selected)
    localStorage.setItem("gem_total_exhibits", tour.stopsCount)
    localStorage.setItem("gem_total_questions", "0")

    navigate(hasLanguage && hasHeadphone ? "/headphone" : "/language")
  }

  if (loading) {
    return <div className="shell"><div className="card"><h1 className="card-title">Loading tours...</h1></div></div>
  }

  if (error) {
    return <div className="shell"><div className="card"><h1 className="card-title">Backend error</h1><p className="card-sub">{error}</p></div></div>
  }

  return (
    <div className="shell">
      <div className="card">
        <div className="step-badge">Step 2 of 5 · Tour Selection</div>
        <h1 className="card-title">Select Your Tour</h1>
        <p className="card-sub">Choose one guided experience for your museum visit.</p>
        <div className="divider">𓊽</div>

        {tours.map((tour) => (
          <button
            key={tour.id}
            className={`tour-card ${selected === tour.id ? "active" : ""}`}
            onClick={() => setSelected(tour.id)}
          >
            <div className="tour-title">{tour.title}</div>
            <div className="tour-meta">
              <span>{tour.duration}</span>
              <span>{tour.stopsCount} stops</span>
              <span>{tour.level}</span>
            </div>
            <div className="tour-desc">{tour.desc}</div>
          </button>
        ))}

        <button className="btn-primary" disabled={!selected} onClick={continueToLanguage}>
          Continue →
        </button>
        <button className="btn-ghost" onClick={() => navigate("/signup")}>Back</button>
      </div>
    </div>
  )
}
