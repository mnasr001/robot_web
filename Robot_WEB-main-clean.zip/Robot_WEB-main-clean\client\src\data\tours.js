export const TOURS = [
  {
    id: "royal",
    title: "Royal Tombs & Pharaohs",
    duration: "90 min",
    stopsCount: 12,
    level: "All ages",
    desc: "Journey through royal treasures, pharaohs, burial objects, and symbols of kingship.",
  },
  {
    id: "daily",
    title: "Daily Life in Ancient Egypt",
    duration: "60 min",
    stopsCount: 8,
    level: "Families",
    desc: "Discover how ordinary Egyptians lived, worked, ate, wrote, and worshipped.",
  },
  {
    id: "gods",
    title: "Gods & Mythology",
    duration: "75 min",
    stopsCount: 10,
    level: "All ages",
    desc: "Explore ancient Egyptian gods, sacred symbols, temples, myths, and afterlife beliefs.",
  },
  {
    id: "science",
    title: "Science & Innovation",
    duration: "50 min",
    stopsCount: 7,
    level: "Students",
    desc: "Explore ancient Egyptian engineering, medicine, mathematics, writing, and astronomy.",
  },
];

export function getTourById(tourId) {
  return TOURS.find((tour) => tour.id === tourId) || TOURS[0];
}
