import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { api } from "../api"

export default function FeedbackPage() {
  const navigate = useNavigate()

  const visitor = JSON.parse(localStorage.getItem("gem_visitor") || "null")
  const tourId = localStorage.getItem("gem_tour") || ""
  const language = localStorage.getItem("gem_language") || ""

  const [rating, setRating] = useState(0)
  const [message, setMessage] = useState("")
  const [status, setStatus] = useState("")
  const [saving, setSaving] = useState(false)

  async function submitFeedback() {
    if (!rating) {
      setStatus("Please choose a star rating before submitting.")
      return
    }

    setSaving(true)
    setStatus("")

    try {
      await api.createFeedback({
        visitorName: visitor?.name || "",
        email: visitor?.email || "",
        tourId,
        language,
        rating,
        message: message.trim(),
      })

      setStatus("Thank you. Your feedback has been saved.")

      setTimeout(() => {
        navigate("/")
      }, 1200)
    } catch (error) {
      setStatus(`Feedback save failed: ${error.message}`)
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="shell">
      <div className="card">
        <div className="step-badge">Final Step · Feedback</div>

        <h1 className="card-title">How Was Your Tour?</h1>

        <p className="card-sub">
          Rate your experience and leave a short message for the museum team.
        </p>

        <div className="divider">𓋹</div>

        <div className="rating-stars">
          {[1, 2, 3, 4, 5].map((star) => (
            <button
              key={star}
              type="button"
              className={star <= rating ? "star active" : "star"}
              onClick={() => setRating(star)}
              aria-label={`${star} star rating`}
            >
              ★
            </button>
          ))}
        </div>

        <p className="rating-text">
          {rating ? `You selected ${rating} out of 5 stars.` : "Choose a rating."}
        </p>

        <label className="field">
          <span>Feedback Message</span>

          <textarea
            value={message}
            onChange={(event) => setMessage(event.target.value)}
            placeholder="Write your feedback here..."
            rows="5"
          />
        </label>

        <button
          className="btn-primary"
          type="button"
          onClick={submitFeedback}
          disabled={saving}
        >
          {saving ? "Saving Feedback..." : "Submit Feedback"}
        </button>

        <button
          className="btn-ghost"
          type="button"
          onClick={() => navigate("/")}
        >
          Back to Start
        </button>

        {status && <p className="notice-text">{status}</p>}
      </div>
    </div>
  )
}