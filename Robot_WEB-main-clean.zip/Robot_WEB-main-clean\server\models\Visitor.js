const mongoose = require("mongoose")

const visitorSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    email: {
      type: String,
      required: true,
      trim: true,
      lowercase: true,
      index: true,
    },
    age: { type: String, required: true },

    languageCode: { type: String, default: "" },
    languageLabel: { type: String, default: "" },

    headphoneId: { type: String, default: "" },
    headphoneRack: { type: String, default: "" },
    headphoneLanguage: { type: String, default: "" },
  },
  { timestamps: true }
)

module.exports = mongoose.model("Visitor", visitorSchema)