import { useNavigate } from "react-router-dom"

export default function SetupRequired({ missingLanguage, missingTour }) {
  const navigate = useNavigate()
  const nextPath = missingTour ? "/tour" : "/language"

  return (
    <div className="shell">
      <div className="card center-card">
        <div className="step-badge">Setup Required</div>
        <h1 className="card-title">Complete Setup First</h1>
        <p className="card-sub">
          {missingTour && missingLanguage
            ? "Please select a tour, then choose your tour language."
            : missingTour
              ? "Please select a tour before continuing."
              : "Please choose your tour language before continuing."}
        </p>
        <div className="divider">𓋹</div>

        <button className="btn-primary" onClick={() => navigate(nextPath)}>
          Continue Setup →
        </button>
        <button className="btn-ghost" onClick={() => navigate("/signup")}>
          Back to Visitor Access
        </button>
      </div>
    </div>
  )
}
