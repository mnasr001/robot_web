const mongoose = require("mongoose")

const guidanceSchema = new mongoose.Schema(
  {
    tourId: {
      type: String,
      required: true,
      index: true,
    },
    fromExhibitId: {
      type: Number,
      required: true,
      index: true,
    },
    placeId: {
      type: String,
      required: true,
    },
    placeName: {
      type: String,
      required: true,
    },
    guidance: {
      type: String,
      required: true,
    },
    estimatedTime: {
      type: String,
      default: "",
    },
    order: {
      type: Number,
      default: 1,
    },
  },
  { timestamps: true }
)

guidanceSchema.index(
  { tourId: 1, fromExhibitId: 1, placeId: 1 },
  { unique: true }
)

module.exports = mongoose.model("Guidance", guidanceSchema)