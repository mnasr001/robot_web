const express = require("express")
const Tour = require("../models/Tour")

const router = express.Router()

router.get("/", async (req, res) => {
  try {
    const tours = await Tour.find().sort({ id: 1 })
    res.json(tours)
  } catch (error) {
    res.status(500).json({ message: error.message })
  }
})

router.get("/:tourId", async (req, res) => {
  try {
    const tour = await Tour.findOne({ id: req.params.tourId })
    if (!tour) return res.status(404).json({ message: "Tour not found" })
    res.json(tour)
  } catch (error) {
    res.status(500).json({ message: error.message })
  }
})

module.exports = router
