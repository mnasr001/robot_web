import { useNavigate } from "react-router-dom"

export default function WelcomePage() {
  const navigate = useNavigate()

  return (
    <div className="shell center-shell">
      <div className="welcome-hero">
        <div className="gem-wordmark">Grand Egyptian Museum · Tour Guide System</div>

        <svg className="scarab-svg" width="64" height="64" viewBox="0 0 64 64">
          <path d="M32 8c7 0 13 6 13 13v3h7v5h-7v6h8v5h-9c-2 9-7 16-12 16S22 49 20 40h-9v-5h8v-6h-7v-5h7v-3C19 14 25 8 32 8Z" fill="none" stroke="currentColor" strokeWidth="2" />
          <path d="M24 24h16M22 33h20M25 42h14M32 9v46" stroke="currentColor" strokeWidth="2" />
        </svg>

        <div className="museum-border-top" />
        <h1 className="welcome-main-title">Welcome to the Grand Egyptian Museum</h1>
        <div className="welcome-glyph-strip">𓂀 𓋹 𓊽 𓇋 𓏏</div>
        <p className="welcome-subtitle">
          Begin your guided journey with Kemet, your intelligent museum tour robot.
        </p>
        <div className="museum-border-bottom" />

        <button className="btn-primary" onClick={() => navigate("/signup")}>
          Start Your Tour →
        </button>
      </div>
    </div>
  )
}
