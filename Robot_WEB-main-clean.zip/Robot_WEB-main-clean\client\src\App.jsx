import { Navigate, Route, Routes, useLocation } from "react-router-dom"

import WelcomePage from "./pages/WelcomePage"
import SignUpPage from "./pages/SignUpPage"
import TourSelectPage from "./pages/TourSelectPage"
import LanguagePage from "./pages/LanguagePage"
import HeadphonePage from "./pages/HeadphonePage"
import ExhibitPage from "./pages/ExhibitPage"
import VisitorAssistancePage from "./pages/VisitorAssistancePage"
import QATimerPage from "./pages/QATimerPage"
import TourCompletePage from "./pages/TourCompletePage"
import FeedbackPage from "./pages/FeedbackPage"

const steps = [
  "/",
  "/signup",
  "/tour",
  "/language",
  "/headphone",
  "/exhibit",
  "/facilities",
  "/qa",
  "/complete",
  "/feedback",
]

function getStep(pathname) {
  return steps.findIndex((step) =>
    step === "/" ? pathname === "/" : pathname.startsWith(step),
  )
}

export default function App() {
  const currentStep = getStep(useLocation().pathname)

  return (
    <>
      <Routes>
        <Route path="/" element={<WelcomePage />} />
        <Route path="/signup" element={<SignUpPage />} />
        <Route path="/tour" element={<TourSelectPage />} />
        <Route path="/language" element={<LanguagePage />} />
        <Route path="/headphone" element={<HeadphonePage />} />

        <Route path="/exhibit" element={<Navigate to="/exhibit/1" replace />} />
        <Route path="/exhibit/:exhibitId" element={<ExhibitPage />} />

        <Route path="/facilities" element={<Navigate to="/facilities/1" replace />} />
        <Route path="/facilities/:exhibitId" element={<VisitorAssistancePage />} />

        <Route path="/qa" element={<Navigate to="/qa/1" replace />} />
        <Route path="/qa/:exhibitId" element={<QATimerPage />} />

        <Route path="/complete" element={<TourCompletePage />} />
        <Route path="/feedback" element={<FeedbackPage />} />

        <Route path="/go" element={<Navigate to="/exhibit/1" replace />} />
        <Route path="/go/:exhibitId" element={<Navigate to="/exhibit/1" replace />} />

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>

      {currentStep !== -1 && (
        <div className="progress-dots">
          {steps.map((step, index) => (
            <span
              key={step}
              className={
                index === currentStep ? "active" : index < currentStep ? "done" : ""
              }
            />
          ))}
        </div>
      )}
    </>
  )
}