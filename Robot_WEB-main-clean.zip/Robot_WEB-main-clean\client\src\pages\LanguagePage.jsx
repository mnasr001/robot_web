import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { api } from "../api"
import SetupRequired from "../components/SetupRequired"

const languages = [
  { code: "en", label: "English", native: "English", flag: "🇬🇧", rack: "A" },
  { code: "ar", label: "Arabic", native: "العربية", flag: "🇪🇬", rack: "B" },
  { code: "fr", label: "French", native: "Français", flag: "🇫🇷", rack: "C" },
  { code: "de", label: "German", native: "Deutsch", flag: "🇩🇪", rack: "D" },
]

function readUsers() {
  return JSON.parse(localStorage.getItem("gem_users") || "[]")
}

function saveUserLocally(user) {
  const users = readUsers().filter((item) => item.email !== user.email)
  localStorage.setItem("gem_users", JSON.stringify([...users, user]))
}

function headphoneFor(language) {
  const number = Math.floor(100 + Math.random() * 900)

  return {
    id: `${language.rack}-${number}`,
    rack: language.rack,
    language: language.label,
  }
}

function assignLanguage(user, languageCode) {
  const language = languages.find((item) => item.code === languageCode)

  if (!language) {
    return user
  }

  const headphone = headphoneFor(language)

  return {
    ...user,
    languageCode: language.code,
    languageLabel: language.label,
    headphoneId: headphone.id,
    headphoneRack: headphone.rack,
    headphoneLanguage: headphone.language,
  }
}

function saveSession(user) {
  localStorage.setItem("gem_visitor", JSON.stringify(user))
  localStorage.setItem("gem_current_user_email", user.email)

  localStorage.setItem("gem_language", user.languageCode || "")
  localStorage.setItem("gem_headphone", user.headphoneId || "")
  localStorage.setItem("gem_headphone_rack", user.headphoneRack || "")
  localStorage.setItem("gem_headphone_language", user.headphoneLanguage || "")
}

export default function LanguagePage() {
  const navigate = useNavigate()

  const tourId = localStorage.getItem("gem_tour")
  const visitor = JSON.parse(localStorage.getItem("gem_visitor") || "null")

  const [selected, setSelected] = useState(
    visitor?.languageCode || localStorage.getItem("gem_language") || ""
  )
  const [message, setMessage] = useState("")

  if (!tourId) {
    return <SetupRequired missingTour />
  }

  async function continueToHeadphone() {
    const language = languages.find((item) => item.code === selected)

    if (!language) {
      setMessage("Please choose a language.")
      return
    }

    if (visitor?.email) {
      const updatedVisitor = assignLanguage(visitor, selected)

      try {
        const savedVisitor = await api.createVisitor(updatedVisitor)

        saveUserLocally(savedVisitor)
        saveSession(savedVisitor)

        navigate("/headphone")
      } catch (error) {
        setMessage(`Backend save failed: ${error.message}`)
      }

      return
    }

    const headphone = headphoneFor(language)

    localStorage.setItem("gem_language", language.code)
    localStorage.setItem("gem_headphone", headphone.id)
    localStorage.setItem("gem_headphone_rack", headphone.rack)
    localStorage.setItem("gem_headphone_language", headphone.language)

    navigate("/headphone")
  }

  return (
    <div className="shell">
      <div className="card">
        <div className="step-badge">Language & Headphone</div>

        <h1 className="card-title">Choose Tour Language</h1>

        <p className="card-sub">
          Choose the language you want to hear during the tour.
        </p>

        <div className="divider">𓋹</div>

        <div className="select-grid cols-2">
          {languages.map((language) => (
            <button
              type="button"
              key={language.code}
              className={`select-card ${
                selected === language.code ? "active" : ""
              }`}
              onClick={() => setSelected(language.code)}
            >
              <span className="sc-flag">{language.flag}</span>
              <span className="sc-label">{language.label}</span>
              <span className="sc-sub">{language.native}</span>
              <span className="sc-sub">Rack {language.rack}</span>
            </button>
          ))}
        </div>

        <button
          className="btn-primary"
          disabled={!selected}
          onClick={continueToHeadphone}
        >
          Assign Headphone →
        </button>

        <button className="btn-ghost" onClick={() => navigate("/tour")}>
          Back
        </button>

        {message && <p className="notice-text">{message}</p>}
      </div>
    </div>
  )
}