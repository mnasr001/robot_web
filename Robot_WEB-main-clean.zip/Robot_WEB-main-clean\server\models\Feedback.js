const mongoose = require("mongoose")

const feedbackSchema = new mongoose.Schema(
  {
    visitorName: {
      type: String,
      default: "",
    },

    email: {
      type: String,
      default: "",
      trim: true,
      lowercase: true,
    },

    tourId: {
      type: String,
      default: "",
    },

    language: {
      type: String,
      default: "",
    },

    rating: {
      type: Number,
      required: true,
      min: 1,
      max: 5,
    },

    message: {
      type: String,
      default: "",
    },
  },
  { timestamps: true }
)

module.exports = mongoose.model("Feedback", feedbackSchema)