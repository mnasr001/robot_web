const mongoose = require("mongoose")

const tourSchema = new mongoose.Schema(
  {
    id: { type: String, required: true, unique: true },
    tourId: { type: String, required: true, unique: true },
    title: { type: String, required: true },
    duration: { type: String, required: true },
    stopsCount: { type: Number, required: true },
    level: { type: String, required: true },
    desc: { type: String, required: true },
  },
  { timestamps: true }
)

module.exports = mongoose.model("Tour", tourSchema)
