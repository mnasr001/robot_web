import { useEffect, useState } from "react"
import { useNavigate, useParams } from "react-router-dom"
import { api } from "../api"
import SetupRequired from "../components/SetupRequired"

export default function VisitorAssistancePage() {
  const navigate = useNavigate()
  const { exhibitId } = useParams()

  const tourId = localStorage.getItem("gem_tour")
  const language = localStorage.getItem("gem_language")

  const [tour, setTour] = useState(null)
  const [exhibit, setExhibit] = useState(null)
  const [guidanceItems, setGuidanceItems] = useState([])
  const [selectedGuidance, setSelectedGuidance] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    if (!tourId || !language) return

    async function loadData() {
      try {
        const tourData = await api.getTour(tourId)
        const exhibitData = await api.getExhibit(tourId, exhibitId)
        const guidanceData = await api.getGuidance(tourId, exhibitId)

        setTour(tourData)
        setExhibit(exhibitData)
        setGuidanceItems(guidanceData)
      } catch (err) {
        setError(err.message)
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [tourId, language, exhibitId])

  if (!tourId || !language) {
    return <SetupRequired missingTour={!tourId} missingLanguage={!language} />
  }

  if (loading) {
    return (
      <div className="shell">
        <div className="card">
          <h1 className="card-title">Loading guidance...</h1>
        </div>
      </div>
    )
  }

  if (error || !tour || !exhibit) {
    return (
      <div className="shell">
        <div className="card">
          <h1 className="card-title">Backend Error</h1>
          <p className="card-sub">{error}</p>

          <button className="btn-primary" onClick={() => navigate(-1)}>
            Back
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="shell">
      <div className="card">
        <div className="step-badge">{tour.title} · Visitor Assistance</div>

        <h1 className="card-title">Need Guidance?</h1>

        <p className="card-sub">
          Choose where you want to go from your current exhibit:
          {" "}
          <strong>{exhibit.name}</strong>
        </p>

        <div className="divider">𓊽</div>

        {guidanceItems.length === 0 ? (
          <p className="card-sub">
            No guidance places are saved for this exhibit yet.
          </p>
        ) : (
          <div className="select-grid cols-2">
            {guidanceItems.map((item) => (
              <button
                type="button"
                key={item._id}
                className={`select-card ${
                  selectedGuidance?._id === item._id ? "active" : ""
                }`}
                onClick={() => setSelectedGuidance(item)}
              >
                <span className="sc-label">{item.placeName}</span>

                {item.estimatedTime && (
                  <span className="sc-sub">
                    {item.estimatedTime}
                  </span>
                )}
              </button>
            ))}
          </div>
        )}

        {selectedGuidance && (
          <div className="exhibit-card">
            <div className="exhibit-num">Guidance</div>

            <div className="exhibit-name">
              {selectedGuidance.placeName}
            </div>

            {selectedGuidance.estimatedTime && (
              <div className="exhibit-fact">
                Estimated time: {selectedGuidance.estimatedTime}
              </div>
            )}

            <p className="card-sub">
              {selectedGuidance.guidance}
            </p>
          </div>
        )}

        <button
          className="btn-primary"
          onClick={() => navigate(`/exhibit/${exhibit.id}`)}
        >
          Back to Exhibit
        </button>

        <button className="btn-ghost" onClick={() => navigate("/complete")}>
          End Tour
        </button>
      </div>
    </div>
  )
}