const dns = require("dns");
dns.setServers(["8.8.8.8", "1.1.1.1"]);


const express = require("express")
const cors = require("cors")
const mongoose = require("mongoose")
require("dotenv").config()


const tourRoutes = require("./routes/tours")
const exhibitRoutes = require("./routes/exhibits")
const questionRoutes = require("./routes/questions")
const visitorRoutes = require("./routes/visitors")
const feedbackRoutes = require("./routes/feedback")
const guidanceRoutes = require("./routes/guidance")


const app = express()
const PORT = process.env.PORT || 5000

app.use(
  cors({
    origin: [
      "http://localhost:5173",
      "http://127.0.0.1:5173",
      "http://localhost:5174",
      "http://127.0.0.1:5174",
      "http://localhost:5175",
      "http://127.0.0.1:5175",
    ],
    credentials: true,
  })
)
app.use(express.json())

app.get("/api/health", (req, res) => {
  res.json({ ok: true, message: "Kemet backend is running" })
})

app.use("/api/tours", tourRoutes)
app.use("/api/exhibits", exhibitRoutes)
app.use("/api/questions", questionRoutes)
app.use("/api/visitors", visitorRoutes)
app.use("/api/feedback", feedbackRoutes)
app.use("/api/guidance", guidanceRoutes)


async function startServer() {
  try {
    if (!process.env.MONGODB_URI) {
      throw new Error("MONGODB_URI is missing. Add it inside server/.env")
    }

    await mongoose.connect(process.env.MONGODB_URI)
    console.log("✅ Connected to MongoDB Atlas")

    app.listen(PORT, () => {
      console.log(`✅ Backend running on http://localhost:${PORT}`)
    })
  } catch (error) {
    console.error("❌ Backend failed to start")
    console.error(error.message)
    process.exit(1)
  }
}

startServer()
