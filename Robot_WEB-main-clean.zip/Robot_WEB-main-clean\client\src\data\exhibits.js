export const TOUR_EXHIBITS = {
  royal: [
    {
      id: 1,
      name: "The Mask of Tutankhamun",
      hall: "Hall of the Golden Pharaoh",
      subtitle: "A royal treasure from ancient Egypt",
      period: "New Kingdom",
      material: "Gold and precious stones",
      purpose: "Royal funerary mask",
      summary:
        "This mask represents royal power, protection, and the ancient Egyptian belief in the afterlife.",
    },
    {
      id: 2,
      name: "Royal Golden Throne",
      hall: "Royal Collection Gallery",
      subtitle: "A symbol of power, ceremony, and kingship",
      period: "New Kingdom",
      material: "Wood, gold, and colored inlays",
      purpose: "Royal ceremonial seat",
      summary:
        "This throne reflects the luxury of the royal court and the importance of ceremony in ancient Egypt.",
    },
    {
      id: 3,
      name: "Canopic Shrine",
      hall: "Afterlife Beliefs Gallery",
      subtitle: "A sacred object connected to mummification",
      period: "New Kingdom",
      material: "Gilded wood",
      purpose: "Protective burial shrine",
      summary:
        "Canopic objects were connected to preserving and protecting the body for the journey to the afterlife.",
    },
    {
      id: 4,
      name: "Royal Chariot",
      hall: "Pharaohs and Power",
      subtitle: "A vehicle of movement, ceremony, and royal status",
      period: "New Kingdom",
      material: "Wood, leather, and gold decoration",
      purpose: "Royal transport and display",
      summary:
        "The chariot shows how kings used design, speed, and decoration to express power and status.",
    },
    {
      id: 5,
      name: "Royal Sarcophagus",
      hall: "Burial Chamber Gallery",
      subtitle: "A protective container for the royal body",
      period: "New Kingdom",
      material: "Stone and decorated surfaces",
      purpose: "Burial protection",
      summary:
        "The sarcophagus protected the body and carried religious symbols for safe passage to the afterlife.",
    },
    {
      id: 6,
      name: "Pectoral Necklace",
      hall: "Royal Jewelry Gallery",
      subtitle: "A decorated royal chest ornament",
      period: "New Kingdom",
      material: "Gold and colorful stones",
      purpose: "Royal protection and beauty",
      summary:
        "Royal jewelry was not only decorative; it also carried symbols of protection and divine power.",
    },
    {
      id: 7,
      name: "Golden Sandals",
      hall: "Treasures of the King",
      subtitle: "A rare personal item from royal burial equipment",
      period: "New Kingdom",
      material: "Gold",
      purpose: "Symbolic royal footwear",
      summary:
        "Objects like sandals show how even personal items could become sacred symbols in royal burials.",
    },
    {
      id: 8,
      name: "Ushabti Figures",
      hall: "Afterlife Servants",
      subtitle: "Small figures made to serve in the afterlife",
      period: "Ancient Egypt",
      material: "Faience, wood, or stone",
      purpose: "Funerary servant figures",
      summary:
        "Ushabti figures were placed in tombs to magically serve the deceased in the afterlife.",
    },
    {
      id: 9,
      name: "Royal Seal",
      hall: "Authority and Administration",
      subtitle: "A mark of royal ownership and official power",
      period: "Ancient Egypt",
      material: "Stone or clay impression",
      purpose: "Official identification",
      summary:
        "Seals helped identify royal property, secure goods, and represent the authority of the king.",
    },
    {
      id: 10,
      name: "Ceremonial Dagger",
      hall: "Royal Weapons Gallery",
      subtitle: "A decorated weapon linked with royal identity",
      period: "New Kingdom",
      material: "Metal, gold, and decorated handle",
      purpose: "Ceremonial protection",
      summary:
        "Royal weapons often combined practical design with symbolic meaning and elite craftsmanship.",
    },
    {
      id: 11,
      name: "Pharaoh Statue",
      hall: "Kingship Gallery",
      subtitle: "A sculpted image of royal authority",
      period: "Ancient Egypt",
      material: "Stone",
      purpose: "Royal representation",
      summary:
        "Statues presented the pharaoh as powerful, eternal, and connected to divine order.",
    },
    {
      id: 12,
      name: "Royal Burial Chest",
      hall: "Tomb Treasures Gallery",
      subtitle: "A decorated chest for precious burial objects",
      period: "New Kingdom",
      material: "Wood and painted decoration",
      purpose: "Storage for royal treasures",
      summary:
        "Burial chests protected valuable objects that were believed to help the king in the afterlife.",
    },
  ],

  daily: [
    {
      id: 1,
      name: "Scribe's Palette",
      hall: "Writing and Education",
      subtitle: "A tool used for writing and recording information",
      period: "Ancient Egypt",
      material: "Wood and pigments",
      purpose: "Writing and administration",
      summary:
        "Writing helped organize government, trade, religion, and daily communication in ancient Egypt.",
    },
    {
      id: 2,
      name: "Bread and Beer Tools",
      hall: "Food and Home Life",
      subtitle: "Tools connected to everyday meals",
      period: "Ancient Egypt",
      material: "Clay, stone, and wood",
      purpose: "Food preparation",
      summary:
        "Bread and beer were important parts of daily life and appeared in both homes and offerings.",
    },
    {
      id: 3,
      name: "Linen Clothing",
      hall: "Clothing and Identity",
      subtitle: "Simple clothing made for Egypt's climate",
      period: "Ancient Egypt",
      material: "Linen",
      purpose: "Daily clothing",
      summary:
        "Linen clothing was light, practical, and suitable for Egypt's hot environment.",
    },
    {
      id: 4,
      name: "Cosmetic Spoon",
      hall: "Beauty and Personal Care",
      subtitle: "A decorated object for oils or cosmetics",
      period: "Ancient Egypt",
      material: "Wood or stone",
      purpose: "Personal care",
      summary:
        "Cosmetics and scented oils were part of hygiene, beauty, and social life.",
    },
    {
      id: 5,
      name: "Fishing Tools",
      hall: "Work and the Nile",
      subtitle: "Tools linked to food, work, and river life",
      period: "Ancient Egypt",
      material: "Bone, wood, and metal",
      purpose: "Fishing and food gathering",
      summary:
        "The Nile provided food, transport, and resources that shaped daily Egyptian life.",
    },
    {
      id: 6,
      name: "Household Pottery",
      hall: "Homes and Storage",
      subtitle: "Everyday vessels for storage and cooking",
      period: "Ancient Egypt",
      material: "Clay",
      purpose: "Cooking and storage",
      summary:
        "Pottery was one of the most common tools used in ancient Egyptian homes.",
    },
    {
      id: 7,
      name: "Children's Toys",
      hall: "Family Life",
      subtitle: "Objects that show family and childhood",
      period: "Ancient Egypt",
      material: "Wood, clay, or fabric",
      purpose: "Play and learning",
      summary:
        "Toys reveal that family life and childhood were important parts of ancient society.",
    },
    {
      id: 8,
      name: "Farmer's Tools",
      hall: "Agriculture and Work",
      subtitle: "Tools used in fields along the Nile",
      period: "Ancient Egypt",
      material: "Wood and metal",
      purpose: "Farming",
      summary:
        "Agriculture supported the economy and depended heavily on the Nile's seasonal cycle.",
    },
  ],

  gods: [
    {
      id: 1,
      name: "Ra Sun Symbol",
      hall: "Solar Beliefs",
      subtitle: "A symbol connected to the sun and creation",
      period: "Ancient Egypt",
      material: "Stone or painted relief",
      purpose: "Religious symbol",
      summary:
        "Ra was closely connected with the sun, creation, and the daily cycle of life.",
    },
    {
      id: 2,
      name: "Osiris Figure",
      hall: "Afterlife Myths",
      subtitle: "A god linked with resurrection and the afterlife",
      period: "Ancient Egypt",
      material: "Bronze or wood",
      purpose: "Religious devotion",
      summary:
        "Osiris became one of the most important gods in beliefs about death and rebirth.",
    },
    {
      id: 3,
      name: "Isis Amulet",
      hall: "Divine Protection",
      subtitle: "A protective symbol connected with magic and motherhood",
      period: "Ancient Egypt",
      material: "Faience or stone",
      purpose: "Protection",
      summary:
        "Isis was worshipped as a powerful goddess associated with protection, healing, and family.",
    },
    {
      id: 4,
      name: "Anubis Jackal Figure",
      hall: "Mummification Beliefs",
      subtitle: "A god connected with embalming and tomb protection",
      period: "Ancient Egypt",
      material: "Wood or stone",
      purpose: "Funerary protection",
      summary:
        "Anubis was linked to mummification and the protection of the dead.",
    },
    {
      id: 5,
      name: "Horus Falcon",
      hall: "Kingship and Sky",
      subtitle: "A divine symbol of kingship and protection",
      period: "Ancient Egypt",
      material: "Stone or bronze",
      purpose: "Royal and religious symbol",
      summary:
        "Horus was connected with the sky and with the living king of Egypt.",
    },
    {
      id: 6,
      name: "Bastet Cat Figure",
      hall: "Home and Protection",
      subtitle: "A goddess associated with protection and domestic life",
      period: "Ancient Egypt",
      material: "Bronze or stone",
      purpose: "Devotion and protection",
      summary:
        "Bastet was linked with protection, music, joy, and the home.",
    },
    {
      id: 7,
      name: "Scarab Symbol",
      hall: "Rebirth Symbols",
      subtitle: "A symbol of renewal and protection",
      period: "Ancient Egypt",
      material: "Stone or faience",
      purpose: "Amulet and symbol",
      summary:
        "The scarab represented rebirth, renewal, and the rising sun.",
    },
    {
      id: 8,
      name: "Book of the Dead Scene",
      hall: "Journey to the Afterlife",
      subtitle: "A scene connected to judgment and the afterlife",
      period: "Ancient Egypt",
      material: "Papyrus or painted surface",
      purpose: "Funerary guidance",
      summary:
        "Afterlife texts helped guide the deceased through spiritual challenges after death.",
    },
    {
      id: 9,
      name: "Temple Offering Table",
      hall: "Ritual and Worship",
      subtitle: "A surface used for offerings to gods",
      period: "Ancient Egypt",
      material: "Stone",
      purpose: "Religious offering",
      summary:
        "Offerings were used to maintain a relationship between people, kings, and the gods.",
    },
    {
      id: 10,
      name: "Protective Eye Amulet",
      hall: "Sacred Symbols",
      subtitle: "A symbol of protection, health, and restoration",
      period: "Ancient Egypt",
      material: "Faience or stone",
      purpose: "Protection",
      summary:
        "Eye symbols were widely used for protection and healing in ancient Egyptian belief.",
    },
  ],

  science: [
    {
      id: 1,
      name: "Architect's Measuring Rod",
      hall: "Engineering and Building",
      subtitle: "A tool connected to measurement and construction",
      period: "Ancient Egypt",
      material: "Wood",
      purpose: "Measurement",
      summary:
        "Accurate measurement helped Egyptians plan buildings, temples, and monuments.",
    },
    {
      id: 2,
      name: "Medical Papyrus",
      hall: "Medicine and Healing",
      subtitle: "A text connected to treatment and diagnosis",
      period: "Ancient Egypt",
      material: "Papyrus",
      purpose: "Medical knowledge",
      summary:
        "Medical texts show that Egyptians developed organized ideas about health and healing.",
    },
    {
      id: 3,
      name: "Astronomy Chart",
      hall: "Sky and Time",
      subtitle: "A guide to stars, seasons, and religious time",
      period: "Ancient Egypt",
      material: "Painted surface or papyrus",
      purpose: "Timekeeping and observation",
      summary:
        "Observing the sky helped Egyptians connect religion, agriculture, and timekeeping.",
    },
    {
      id: 4,
      name: "Water Clock",
      hall: "Time Measurement",
      subtitle: "A device for measuring time using flowing water",
      period: "Ancient Egypt",
      material: "Stone or ceramic",
      purpose: "Timekeeping",
      summary:
        "Water clocks show how ancient societies measured time before mechanical clocks.",
    },
    {
      id: 5,
      name: "Mathematical Tablet",
      hall: "Numbers and Planning",
      subtitle: "An object connected with calculation and problem solving",
      period: "Ancient Egypt",
      material: "Papyrus or writing board",
      purpose: "Mathematics",
      summary:
        "Mathematics was important for building, land measurement, trade, and administration.",
    },
    {
      id: 6,
      name: "Boat Model",
      hall: "Transport and Engineering",
      subtitle: "A model showing Nile travel and design",
      period: "Ancient Egypt",
      material: "Wood",
      purpose: "Transport model",
      summary:
        "Boat design helped Egyptians travel, trade, and move materials along the Nile.",
    },
    {
      id: 7,
      name: "Stone Cutting Tools",
      hall: "Craft and Technology",
      subtitle: "Tools used for shaping hard materials",
      period: "Ancient Egypt",
      material: "Stone, copper, or bronze",
      purpose: "Craft production",
      summary:
        "Toolmaking and skilled labor allowed Egyptians to create large monuments and detailed objects.",
    },
  ],
};

export function getTourExhibits(tourId) {
  return TOUR_EXHIBITS[tourId] || TOUR_EXHIBITS.royal;
}

export function getExhibitById(tourId, exhibitId) {
  const exhibits = getTourExhibits(tourId);
  return exhibits.find((exhibit) => exhibit.id === Number(exhibitId)) || exhibits[0];
}

export function getNextExhibit(tourId, exhibitId) {
  const exhibits = getTourExhibits(tourId);
  const currentIndex = exhibits.findIndex((exhibit) => exhibit.id === Number(exhibitId));
  return exhibits[currentIndex + 1] || null;
}
