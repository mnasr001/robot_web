import { useNavigate } from "react-router-dom"
import SetupRequired from "../components/SetupRequired"

export default function HeadphonePage() {
  const navigate = useNavigate()

  const tourId = localStorage.getItem("gem_tour")
  const language = localStorage.getItem("gem_language")
  const headphone = localStorage.getItem("gem_headphone")
  const rack = localStorage.getItem("gem_headphone_rack")
  const headphoneLanguage = localStorage.getItem("gem_headphone_language")

  if (!tourId || !language) {
    return <SetupRequired missingTour={!tourId} missingLanguage={!language} />
  }

  return (
    <div className="shell">
      <div className="card">
        <div className="step-badge">Step 4 of 5 · Equipment</div>

        <h1 className="card-title">Your Language Headphone</h1>

        <p className="card-sub">
          This headphone was assigned based on your selected language.
        </p>

        <div className="divider">𓇋</div>

        <div className="headphone-display">
          <div className="hid-label">Assigned Headphone ID</div>

          <div className="hid-number">{headphone || "—"}</div>

          <div className="hid-row">
            <div className="sound-wave">
              <span />
              <span />
              <span />
              <span />
              <span />
            </div>

            <span>
              {headphoneLanguage || "Selected language"} · Rack {rack || "—"}
            </span>
          </div>
        </div>

        <button
          className="btn-primary"
          onClick={() => navigate("/exhibit/1")}
        >
          I Have My Headphone →
        </button>

        <button
          className="btn-ghost"
          onClick={() => navigate("/language")}
        >
          Change Language
        </button>

        <button
          className="btn-ghost"
          onClick={() => navigate("/tour")}
        >
          Change Tour
        </button>
      </div>
    </div>
  )
}