const express = require("express")
const Question = require("../models/Question")

const router = express.Router()

router.get("/", async (req, res) => {
  try {
    const { tourId, exhibitId } = req.query

    const filter = {}

    if (tourId) {
      filter.tourId = tourId
    }

    if (exhibitId) {
      filter.exhibitId = Number(exhibitId)
    }

    const questions = await Question.find(filter).sort({
      tourId: 1,
      exhibitId: 1,
      questionNumber: 1,
    })

    res.json(questions)
  } catch (error) {
    res.status(500).json({ message: "Failed to load questions" })
  }
})

module.exports = router