import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { api } from "../api"

const emptyForm = {
  name: "",
  email: "",
  age: "",
}

const languages = [
  { code: "en", label: "English", native: "English", flag: "🇬🇧", rack: "A" },
  { code: "ar", label: "Arabic", native: "العربية", flag: "🇪🇬", rack: "B" },
  { code: "fr", label: "French", native: "Français", flag: "🇫🇷", rack: "C" },
  { code: "de", label: "German", native: "Deutsch", flag: "🇩🇪", rack: "D" },
]

function readUsers() {
  return JSON.parse(localStorage.getItem("gem_users") || "[]")
}

function saveUserLocally(user) {
  const users = readUsers().filter((item) => item.email !== user.email)
  localStorage.setItem("gem_users", JSON.stringify([...users, user]))
}

function headphoneFor(language) {
  const number = Math.floor(100 + Math.random() * 900)

  return {
    id: `${language.rack}-${number}`,
    rack: language.rack,
    language: language.label,
  }
}

function assignLanguage(user, languageCode) {
  const language = languages.find((item) => item.code === languageCode)

  if (!language) {
    return user
  }

  const headphone = headphoneFor(language)

  return {
    ...user,
    languageCode: language.code,
    languageLabel: language.label,
    headphoneId: headphone.id,
    headphoneRack: headphone.rack,
    headphoneLanguage: headphone.language,
  }
}

function saveSession(user) {
  localStorage.removeItem("gem_tour_finished")

  localStorage.setItem("gem_visitor", JSON.stringify(user))
  localStorage.setItem("gem_current_user_email", user.email)

  localStorage.setItem("gem_language", user.languageCode || "")
  localStorage.setItem("gem_headphone", user.headphoneId || "")
  localStorage.setItem("gem_headphone_rack", user.headphoneRack || "")
  localStorage.setItem("gem_headphone_language", user.headphoneLanguage || "")
}

function clearTourSession() {
  ;[
    "gem_tour",
    "gem_total_exhibits",
    "gem_total_questions",
  ].forEach((key) => localStorage.removeItem(key))
}

export default function SignUpPage() {
  const navigate = useNavigate()

  const [mode, setMode] = useState("signup")
  const [form, setForm] = useState(emptyForm)
  const [loginEmail, setLoginEmail] = useState("")
  const [pendingUser, setPendingUser] = useState(null)
  const [loginLanguage, setLoginLanguage] = useState("")
  const [message, setMessage] = useState("")

  function updateField(event) {
    setForm({ ...form, [event.target.name]: event.target.value })
  }

  async function createAccount(event) {
    event.preventDefault()

    const user = {
      name: form.name.trim(),
      email: form.email.trim().toLowerCase(),
      age: form.age.trim(),
      languageCode: "",
      languageLabel: "",
      headphoneId: "",
      headphoneRack: "",
      headphoneLanguage: "",
    }

    if (!user.name || !user.email || !user.age) {
      setMessage("Please fill in your name, email, and age.")
      return
    }

    const localExistingUser = readUsers().find(
      (item) => item.email === user.email
    )

    if (localExistingUser) {
      setLoginEmail(user.email)
      setMode("login")
      setMessage("This email already has an account. Please log in instead.")
      return
    }

    try {
      await api.getVisitorByEmail(user.email)

      setLoginEmail(user.email)
      setMode("login")
      setMessage("This email already has an account. Please log in instead.")
      return
    } catch (error) {
      // Visitor not found, so signup can continue.
    }

    try {
      const savedUser = await api.createVisitor(user)

      saveUserLocally(savedUser)
      saveSession(savedUser)
      clearTourSession()

      navigate("/tour")
    } catch (error) {
      setMessage(`Backend save failed: ${error.message}`)
    }
  }

  async function login(event) {
    event.preventDefault()

    const email = loginEmail.trim().toLowerCase()

    if (!email) {
      setMessage("Please enter your email.")
      return
    }

    let user = readUsers().find((item) => item.email === email)

    if (!user) {
      try {
        user = await api.getVisitorByEmail(email)
      } catch (error) {
        setMessage("No saved visitor found with this email. Please sign up first.")
        return
      }
    }

    setPendingUser(user)
    setLoginLanguage(user.languageCode || "")

    if (user.languageCode && user.headphoneId) {
      setMode("loginChoice")
      setMessage(
        `Welcome back, ${user.name}. Do you want to keep or change your language?`
      )
    } else {
      setMode("loginLanguage")
      setMessage("Please choose your tour language.")
    }
  }

  function continueWithSavedLanguage() {
    if (!pendingUser) return

    saveUserLocally(pendingUser)
    saveSession(pendingUser)
    clearTourSession()

    navigate("/tour")
  }

  async function saveChangedLanguage() {
    if (!pendingUser) return

    if (!loginLanguage) {
      setMessage("Please choose your tour language.")
      return
    }

    const updatedUser = assignLanguage(pendingUser, loginLanguage)

    try {
      const savedUser = await api.createVisitor(updatedUser)

      saveUserLocally(savedUser)
      saveSession(savedUser)
      clearTourSession()

      navigate("/tour")
    } catch (error) {
      setMessage(`Backend save failed: ${error.message}`)
    }
  }

  function resetForm() {
    setForm(emptyForm)
    setLoginEmail("")
    setPendingUser(null)
    setLoginLanguage("")
    setMessage("")
  }

  return (
    <div className="shell">
      <div className="card">
        <div className="step-badge">Step 1 of 5 · Visitor Access</div>

        <h1 className="card-title">Visitor Access</h1>

        <p className="card-sub">
          Create a visitor profile or continue with a saved one.
        </p>

        <div className="divider">𓋹</div>

        <div className="button-row">
          <button
            type="button"
            className={mode === "signup" ? "btn-primary" : "btn-ghost"}
            onClick={() => {
              resetForm()
              setMode("signup")
            }}
          >
            Sign Up
          </button>

          <button
            type="button"
            className={mode === "login" ? "btn-primary" : "btn-ghost"}
            onClick={() => {
              resetForm()
              setMode("login")
            }}
          >
            Login
          </button>
        </div>

        {mode === "signup" && (
          <form onSubmit={createAccount}>
            <label className="field">
              <span>Full Name</span>
              <input
                name="name"
                value={form.name}
                onChange={updateField}
                placeholder="Enter your name"
              />
            </label>

            <label className="field">
              <span>Email</span>
              <input
                name="email"
                value={form.email}
                onChange={updateField}
                placeholder="name@example.com"
              />
            </label>

            <label className="field">
              <span>Age</span>
              <input
                name="age"
                value={form.age}
                onChange={updateField}
                placeholder="Enter your age"
              />
            </label>

            <button className="btn-primary" type="submit">
              Continue to Tour →
            </button>
          </form>
        )}

        {mode === "login" && (
          <form onSubmit={login}>
            <label className="field">
              <span>Email</span>
              <input
                value={loginEmail}
                onChange={(event) => setLoginEmail(event.target.value)}
                placeholder="Saved email"
              />
            </label>

            <button className="btn-primary" type="submit">
              Login →
            </button>
          </form>
        )}

        {mode === "loginChoice" && pendingUser && (
          <div className="exhibit-card">
            <div className="exhibit-num">Welcome Back</div>

            <div className="exhibit-name">{pendingUser.name}</div>

            <div className="exhibit-fact">
              Current language: {pendingUser.languageLabel || "Not selected"}
            </div>

            <div className="exhibit-fact">
              Headphone: {pendingUser.headphoneId || "Not assigned"}
            </div>

            <button className="btn-primary" onClick={continueWithSavedLanguage}>
              Keep This Language →
            </button>

            <button
              className="btn-ghost"
              onClick={() => {
                setMode("loginLanguage")
                setMessage("Choose a new language. A new headphone will be assigned.")
              }}
            >
              Change Language
            </button>

            <button
              className="btn-ghost"
              onClick={() => {
                setMode("login")
                setMessage("")
              }}
            >
              Back to Login
            </button>
          </div>
        )}

        {mode === "loginLanguage" && pendingUser && (
          <div>
            <div className="exhibit-card">
              <div className="exhibit-num">Language Selection</div>

              <div className="exhibit-name">{pendingUser.name}</div>

              <div className="exhibit-fact">
                Choose the language you want for this visit.
              </div>
            </div>

            <div className="select-grid cols-2">
              {languages.map((language) => (
                <button
                  type="button"
                  key={language.code}
                  className={`select-card ${
                    loginLanguage === language.code ? "active" : ""
                  }`}
                  onClick={() => setLoginLanguage(language.code)}
                >
                  <span className="sc-flag">{language.flag}</span>
                  <span className="sc-label">{language.label}</span>
                  <span className="sc-sub">{language.native}</span>
                  <span className="sc-sub">Rack {language.rack}</span>
                </button>
              ))}
            </div>

            <button
              className="btn-primary"
              disabled={!loginLanguage}
              onClick={saveChangedLanguage}
            >
              Save Language & Continue →
            </button>

            <button
              className="btn-ghost"
              onClick={() => {
                setMode("login")
                setMessage("")
              }}
            >
              Back to Login
            </button>
          </div>
        )}

        {message && <p className="notice-text">{message}</p>}
      </div>
    </div>
  )
}