import { useEffect, useState } from "react"
import { useNavigate, useParams } from "react-router-dom"
import { api } from "../api"
import SetupRequired from "../components/SetupRequired"

export default function QATimerPage() {
  const navigate = useNavigate()
  const { exhibitId } = useParams()

  const tourId = localStorage.getItem("gem_tour")
  const language = localStorage.getItem("gem_language")

  const [questionCount, setQuestionCount] = useState(0)
  const [tour, setTour] = useState(null)
  const [exhibit, setExhibit] = useState(null)
  const [nextExhibit, setNextExhibit] = useState(null)
  const [questions, setQuestions] = useState([])
  const [selectedQuestionId, setSelectedQuestionId] = useState("")
  const [askedQuestionIds, setAskedQuestionIds] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    if (!tourId || !language) return

    async function loadData() {
      try {
        const [tourData, exhibitData, nextData, questionData] =
          await Promise.all([
            api.getTour(tourId),
            api.getExhibit(tourId, exhibitId),
            api.getNextExhibit(tourId, exhibitId),
            api.getQuestions(tourId, exhibitId),
          ])

        setTour(tourData)
        setExhibit(exhibitData)
        setNextExhibit(nextData)
        setQuestions(questionData)
      } catch (err) {
        setError(err.message)
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [tourId, language, exhibitId])

  if (!tourId || !language) {
    return <SetupRequired missingTour={!tourId} missingLanguage={!language} />
  }

  if (loading) {
    return (
      <div className="shell">
        <div className="card">
          <h1 className="card-title">Loading Q&A...</h1>
        </div>
      </div>
    )
  }

  if (error || !tour || !exhibit) {
    return (
      <div className="shell">
        <div className="card">
          <h1 className="card-title">Backend error</h1>
          <p className="card-sub">{error}</p>
        </div>
      </div>
    )
  }

  const selectedQuestion = questions.find(
    (question) => question._id === selectedQuestionId
  )

  function handleQuestionChange(event) {
    const value = event.target.value
    setSelectedQuestionId(value)

    if (!value || askedQuestionIds.includes(value)) {
      return
    }

    const updatedQuestions = [...askedQuestionIds, value]
    setAskedQuestionIds(updatedQuestions)
    setQuestionCount(updatedQuestions.length)

    const totalQuestions =
      Number(localStorage.getItem("gem_total_questions") || 0) + 1

    localStorage.setItem("gem_total_questions", String(totalQuestions))
  }

  function continueTour() {
    navigate(nextExhibit ? `/exhibit/${nextExhibit.id}` : "/complete")
  }

  return (
    <div className="shell">
      <div className="card">
        <div className="step-badge">{tour.title} · Q&A</div>

        <h1 className="card-title">Ask the Robot</h1>

        <p className="card-sub">
          Choose a question about {exhibit.name}. The answer will appear
          automatically.
        </p>

        <div className="divider">𓇼</div>

        <div className="timer-ring-wrap">
          <div className="timer-number">{questionCount}</div>
          <div className="timer-label-text">Questions Asked</div>
        </div>

        <label className="field">
          <span>Choose a question</span>

          <select value={selectedQuestionId} onChange={handleQuestionChange}>
            <option value="">Select a question...</option>

            {questions.map((question) => (
              <option key={question._id} value={question._id}>
                {question.question}
              </option>
            ))}
          </select>
        </label>

        {selectedQuestion && (
          <div className="exhibit-card">
            <div className="exhibit-num">Robot Answer</div>
            <div className="exhibit-name">{selectedQuestion.question}</div>
            <p className="exhibit-fact">{selectedQuestion.answer}</p>
          </div>
        )}

        {questions.length === 0 && (
          <p className="card-sub">
            No questions are saved for this exhibit yet.
          </p>
        )}

        <button className="btn-primary" onClick={continueTour}>
          {nextExhibit ? "Continue to Next Exhibit →" : "Finish Tour →"}
        </button>

        <button
          className="btn-ghost"
          onClick={() => navigate(`/exhibit/${exhibit.id}`)}
        >
          Back to Exhibit
        </button>

        <button
          className="btn-ghost"
          onClick={() => navigate(`/facilities/${exhibit.id}`)}
        >
          Visitor Assistance
        </button>
      </div>
    </div>
  )
}