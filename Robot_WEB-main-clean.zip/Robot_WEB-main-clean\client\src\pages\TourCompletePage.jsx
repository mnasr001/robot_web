import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"
import { api } from "../api"
import SetupRequired from "../components/SetupRequired"

export default function TourCompletePage() {
  const navigate = useNavigate()
  const visitor = JSON.parse(localStorage.getItem("gem_visitor") || "{}")
  const tourId = localStorage.getItem("gem_tour")
  const language = localStorage.getItem("gem_language")
  const [tour, setTour] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    if (!tourId || !language) return

    async function loadTour() {
      try {
        const data = await api.getTour(tourId)
        setTour(data)
      } catch (err) {
        setError(err.message)
      } finally {
        setLoading(false)
      }
    }

    loadTour()
  }, [tourId, language])

  if (!tourId || !language) {
    return <SetupRequired missingTour={!tourId} missingLanguage={!language} />
  }

  if (loading) {
    return <div className="shell"><div className="card"><h1 className="card-title">Loading summary...</h1></div></div>
  }

  if (error || !tour) {
    return <div className="shell"><div className="card"><h1 className="card-title">Backend error</h1><p className="card-sub">{error}</p></div></div>
  }

  const questions = localStorage.getItem("gem_total_questions") || "0"
  const headphone = localStorage.getItem("gem_headphone") || "—"

  return (
    <div className="shell">
      <div className="card center-card">
        <div className="thankyou-tag">Tour Complete</div>
        <span className="ankh-large">𓋹</span>
        <div className="complete-glyph-row">𓂀 𓊽 𓇋 𓏏 𓆑</div>

        <h1 className="card-title">Thank You{visitor.name ? `, ${visitor.name}` : ""}</h1>
        <p className="card-sub">You completed the {tour.title} tour.</p>
        <div className="divider">𓋹</div>

        <div className="info-grid">
          <Info label="Tour" value={tour.title} />
          <Info label="Stops" value={tour.stopsCount} />
          <Info label="Questions" value={questions} />
        </div>

        <p className="notice-text">Please return headphone {headphone} before leaving.</p>

        <button className="btn-primary" onClick={() => navigate("/feedback")}>Give Feedback →</button>
        <button className="btn-ghost" onClick={() => navigate("/")}>Back to Home</button>
      </div>
    </div>
  )
}

function Info({ label, value }) {
  return (
    <div className="info-box">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  )
}
