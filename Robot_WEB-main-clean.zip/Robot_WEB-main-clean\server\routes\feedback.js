const express = require("express")
const Feedback = require("../models/Feedback")

const router = express.Router()

router.post("/", async (req, res) => {
  try {
    const rating = Number(req.body.rating)

    if (!rating || rating < 1 || rating > 5) {
      return res.status(400).json({
        message: "Rating is required and must be between 1 and 5",
      })
    }

    const feedback = await Feedback.create({
      visitorName: req.body.visitorName || "",
      email: req.body.email || "",
      tourId: req.body.tourId || "",
      language: req.body.language || "",
      rating,
      message: req.body.message || "",
    })

    res.status(201).json(feedback)
  } catch (error) {
    res.status(400).json({ message: error.message })
  }
})

router.get("/", async (req, res) => {
  try {
    const feedback = await Feedback.find().sort({ createdAt: -1 })
    res.json(feedback)
  } catch (error) {
    res.status(500).json({ message: "Failed to load feedback" })
  }
})

module.exports = router