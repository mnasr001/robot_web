const express = require("express")
const Guidance = require("../models/Guidance")

const router = express.Router()

router.get("/", async (req, res) => {
  try {
    const { tourId, fromExhibitId } = req.query

    const filter = {}

    if (tourId) {
      filter.tourId = tourId
    }

    if (fromExhibitId) {
      filter.fromExhibitId = Number(fromExhibitId)
    }

    const guidanceItems = await Guidance.find(filter).sort({
      order: 1,
      placeName: 1,
    })

    res.json(guidanceItems)
  } catch (error) {
    res.status(500).json({ message: "Failed to load guidance data" })
  }
})

module.exports = router