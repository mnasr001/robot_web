# Kemet Robot Full Stack Setup

This project has:

- `client/` = React frontend
- `server/` = Node.js + Express + Mongoose backend
- MongoDB Atlas database name = `kemet_robot`

## 1. Prepare MongoDB Atlas

In Atlas, make sure you have:

- Database user with username and password
- Network Access allowing your current IP address
- Connection string from **Connect > Drivers**

Your database should be named:

```txt
kemet_robot
```

## 2. Create the backend `.env` file

Open the project folder in VS Code, then open terminal:

```powershell
cd server
copy .env.example .env
```

Open `server/.env` and replace:

```txt
YOUR_USERNAME
YOUR_PASSWORD
```

with your real Atlas database username and password.

Example shape:

```txt
MONGODB_URI=mongodb+srv://myUser:myPassword@cluster0.fsdhrvl.mongodb.net/kemet_robot?retryWrites=true&w=majority&appName=Cluster0
```

## 3. Install backend packages

Inside `server` folder:

```powershell
npm install
```

## 4. Insert the tours and exhibits into Atlas

Inside `server` folder:

```powershell
npm run seed
```

Expected result:

```txt
Inserted 4 tours
Inserted 37 exhibits
Database seeding finished
```

## 5. Run the backend

Inside `server` folder:

```powershell
npm run dev
```

Expected result:

```txt
Connected to MongoDB Atlas
Backend running on http://localhost:5000
```

Test in browser:

```txt
http://localhost:5000/api/health
http://localhost:5000/api/tours
http://localhost:5000/api/exhibits?tourId=royal
```

## 6. Run the frontend

Open a second terminal:

```powershell
cd client
npm install
npm run dev
```

Open the frontend link, usually:

```txt
http://localhost:5173
```

## Important

Keep the backend terminal running while using the frontend. The frontend now gets tours and exhibits from the backend API, and the backend gets the data from MongoDB Atlas.
