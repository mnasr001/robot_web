const mongoose = require("mongoose")

const questionSchema = new mongoose.Schema(
  {
    tourId: {
      type: String,
      required: true,
      index: true,
    },
    exhibitId: {
      type: Number,
      required: true,
      index: true,
    },
    questionNumber: {
      type: Number,
      required: true,
    },
    question: {
      type: String,
      required: true,
    },
    answer: {
      type: String,
      required: true,
    },
  },
  { timestamps: true }
)

module.exports = mongoose.model("Question", questionSchema)